<template>
  <el-container style="height: 1000px; border: 1px solid #eee">
    <el-container>
      <el-header
        style="text-align: left; font-size: 12px; height: 10%"
        class="headerinfo"
      >
        <!-- <el-dropdown>
        <i class="el-icon-setting" style="margin-right: 15px"></i>
        <el-dropdown-menu slot="dropdown">
          <el-dropdown-item>查看</el-dropdown-item>
          <el-dropdown-item>新增</el-dropdown-item>
          <el-dropdown-item>删除</el-dropdown-item>
        </el-dropdown-menu>
      </el-dropdown> -->
        <span style="margin-left: 20px">姓名：{{ this.userInfo.Name }}</span>
        <span style="margin-left: 20px">卡号：{{ this.userInfo.cardNO }}</span>
        <span style="margin-left: 20px"
          >身份证号：{{ this.userInfo.idCard }}</span
        >
        <span style="margin-left: 20px"
          >检查医疗机构：{{ this.hospitalName }}</span
        >
      </el-header>
      <el-main>
        <!-- <table class="tb"> 
          <tr>
            <td>卡号</td>
            <td>检查名称</td>
            <td>报告时间</td>
            <td>报告结果</td>
          </tr>
          <tr v-for="item in checkInfos" :key="item.id" class="myjg">
            <td>{{ item.patientId }}</td>
            <td>{{ item.title }}</td>
            <td>{{ item.sendTime }}</td>
            <td>
              <span
                style="display: block; color: green; width: 100%; height: 100%"
                v-for="(item, index) in detail"
                :key="index"
                >{{ item.value }}</span
              >
            </td>
          </tr>
        </table> -->
        <el-table
          :data="checkInfos"
          style="background-color: #409eff; width: 100%"
          @row-click="opendetail"
        >
          <el-table-column prop="patientId" label="卡号"> </el-table-column>
          <el-table-column prop="title" label="检查名称"> </el-table-column>
          <el-table-column prop="sendTime" label="报告时间"> </el-table-column>
          <el-table-column prop="values" label="报告结果"> </el-table-column>
        </el-table>
      </el-main>
    </el-container>
    <el-drawer
      title="核酸项目明细查询"
      :visible.sync="drawer"
      :direction="direction"
      :before-close="handleClose"
      class="detail"
    >
      <!-- 弹出的内容 -->
      <el-collapse>
        <el-collapse-item
          v-for="item in checkdetails"
          :key="item.item"
          :title="'检查项目：' + item.item + '    检查结果：' + item.value"
          name="1"
        >
          <p>项目名称：{{ item.itemName }}</p>
          <p>检查名称：{{ item.name }}</p>
          <p>结果：{{ item.value }}</p>
        </el-collapse-item>
      </el-collapse>
    </el-drawer>
       <el-drawer
      title="核酸查询说明"
      :visible.sync="ISHOWJG"
      :direction="direction"
      :before-close="handleClose"
      class="show"
    >
      <!-- 弹出的内容 -->
      <el-collapse>
        <h3>本网站核酸查询只能查询14天内的结果</h3>
      </el-collapse>
    </el-drawer>
  </el-container>
</template>

<script>
var baseUrl = "http://111.47.69.7:9500/api/zhyy";
export default {
  data() {
    return {
      // tableData: Array(20).fill(item),
      drawer: false,
      direction: "ttb",
      userInfo: {
        Name: "",
        idCard: "",
        address: "",
        cardNO: "",
      },
      checkInfos: [],
      checkdetails: [],
      hospitalName: "",
      isshow: true,
      detail: [],
      ISHOWJG:true
    };
  },
  methods: {
    handleClose(done) {
      // this.$confirm('确认关闭？')
      //   .then(() => {
      //     done();
      //   })
      //   .catch(() => {});
      done();
    },
    initData() {
      // var data={
      //   idcard:this.userInfo.idCard
      // }
      // var RequestUrl=baseUrl + "/GetjcHeader?idcard=" + this.userInfo.idCard + "";
      var RequestUrl=baseUrl + "/Getjc?idcard=" + this.userInfo.idCard + "";
      this.$http
        .get(RequestUrl)
        .then((res) => {
          this.checkInfos = res.data.data;
          for (var index = 0; index < res.data.data.length; index++) {
            this.checkInfos[index].hospitalName =
              res.data.data[index].hospitalName;
            this.checkInfos[index].id = res.data.data[index].id;
            this.checkInfos[index].iswsw = res.data.data[index].iswsw;
            this.checkInfos[index].patientId = res.data.data[index].patientId;
            this.checkInfos[index].patientName =
              res.data.data[index].patientName;
            this.checkInfos[index].sendTime = this.getZStime(
              res.data.data[index].sendTime
            );
            this.checkInfos[index].values=res.data.data[index].values;
            this.checkInfos[index].title = res.data.data[index].title;
            // this.queryCheckResult(this.userInfo.idCard,index);
            // this.queryCheckResult(res.data.data[index].id);
            this.hospitalName = res.data.data[index].hospitalName;
            console.log(this.checkInfos);
          }
        });
    },
    getZStime(val) {
      if (val != null) {
        var date = new Date(val);
        return (
          date.getFullYear() +
          "-" +
          (date.getMonth() + 1) +
          "-" +
          date.getDate()
        );
      }
    },
    // queryCheckResult(id) {
    //   var data = {
    //     id: id,
    //     iswsw: "0",
    //   };
    //   this.$http
    //     .post(baseUrl + "/GetjcDetail", data, {
    //       headers: {
    //         async: true,
    //       },
    //     })
    //     .then((jg) => {
    //       if (jg.data.data.code == 404 || jg.data.data.code == 500) {
    //         for (let index = 0; index < jg.data.data.length; index++) {
    //           this.detail[index].value = jg.data.data[index].value;
    //         }
    //       } else {
    //         this.detail[0].value = jg.data.msg;
    //         this.isshow = false;
    //       }
    //     });
    // },
    // bindCheckResult(id) {
    //   var data = {
    //     id: id,
    //     iswsw: "0",
    //   };
    //   this.$http.post(baseUrl + "/GetjcDetail", data).then((jg) => {
    //     return jg.data.data;
    //   });
    // },

    opendetail(obj) {
      this.drawer = true;
      // console.log(obj.id);
      var data = {
        id: obj.id,
        iswsw: "0",
      };
      this.$http
        .post(baseUrl + "/GetjcDetail", data, {
          headers: {
            async: false,
          },
        })
        .then((res) => {
          console.log(res.data.data);
          this.checkdetails = res.data.data;
          this.detail = res.data.data;
        });
      console.log();
    },
  },
  mounted: function () {
    this.checkdetails = [];
    this.checkInfos = [];
    // var myDate = new Date();
    // console.log(this.$root.query.Name);
    // console.log(this.$root.query.idcard);
    // console.log(this.$route.query.idcard);
    this.userInfo.Name = this.$route.query.Name;
    this.userInfo.idCard = this.$route.query.idcard;
    this.userInfo.address = this.$route.query.address;
    this.userInfo.cardNO = this.$route.query.cardNo;

    this.initData();
  }, 
};
</script>


<style lang="scss" scope>
.el-header {
  background-color: #409eff;
  color: #fff;
  height: 60px;
  > span {
    color: #fff;
  }
}

.el-aside {
  color: #fff;
}
.detail {
  height: 200%;
  overflow: auto;
}
.show{
  height: 150%;
  color: red;
  text-align: center;
}
.el-main {
  line-height: 80px;
}
#showjg {
  z-index: 10;
  width: 100%;
  height: 100%;
  text-align: left;
  line-height: 80px;
}
// .tb{
//   height: 50px;
//   width: 100%;
//   >tr{
//     width: 25%;
//     height: 50px;
//   }
//   .myjg{

//   }
// }
</style>