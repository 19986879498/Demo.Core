<template>
  <div class="login-container">
    <el-form
      :model="ruleForm2"
      :rules="rules2"
      status-icon
      ref="ruleForm2"
      label-position="left"
      label-width="0px"
      class="demo-ruleForm login-page"
    >
      <h3 class="title">核酸检测查询</h3>
      <el-form-item prop="IdCard">
        <el-input
          type="text"
          v-model="ruleForm2.IdCard"
          auto-complete="off"
          placeholder="患者身份证号码"
          @keydown.enter.native="Onkeydown"
        ></el-input>
      </el-form-item>
      <el-form-item prop="Phone">
        <el-input
          type="text"
          v-model="ruleForm2.Phone"
          auto-complete="off"
          placeholder="电话"
          @change="YZInfo"
        ></el-input>
      </el-form-item>
      <div class="showyzm">
        <el-form-item prop="validCode" id="yzm">
          <el-input
            type="text"
            v-model="ruleForm2.validCode"
            auto-complete="off"
            placeholder="验证码"
          ></el-input>
        </el-form-item>
        <el-button v-show="sendAuthCode" id="btnyzm" @click="getAuthCode"
          >获取验证码</el-button
        >
        <input type="hidden" name="" v-model="key" />
        <el-button
          v-show="!sendAuthCode"
          id="btnyzm"
          :class="!sendAuthCode ? 'send' : ''"
          @click="getAuthCode"
          aria-disabled="fasle"
          ><span class="auth_text_blue">{{ auth_time }} </span>
          秒后重试</el-button
        >
      </div>

      <!-- <el-checkbox 
                v-model="checked"
                class="rememberme"
            >记住密码</el-checkbox> -->
      <el-form-item style="width: 100%">
        <el-button
          type="primary"
          style="width: 100%"
          :loading="logining"
          @click="toGoQuery"
          >前往查询</el-button
        >
      </el-form-item>
    </el-form>
  </div>
</template>


<script>
// @ is an alias to /src
// import HelloWorld from "@/components/HelloWorld.vue";
var baseUrl = "http://111.47.69.7:9500/api/zhyy";
export default {
  name: "Home",
  data() {
    return {
      logining: false,
      key: "" /*获取短信的key*/,
      ruleForm2: {
        IdCard: "",
        Phone: "",
        validCode: "",
      },
      rules2: {
        cardNo: [
          { required: true, message: "请输入患者身份证号码", trigger: "blur" },
        ],
        validCode: [
          { required: true, message: "请输入验证码", trigger: "blur" },
        ],
      },
      userInfo: {
        status: "",
        patientId: "",
        patientName: "",
        cardNo: "",
        idCardNo: "",
        phone: "",
        address: "",
      },
      userInfos:[],
      checked: false,
      sendAuthCode: true /*布尔值，通过v-show控制显示‘获取按钮’还是‘倒计时’ */,
      auth_time: 0 /*倒计时 计数器*/,
      IsValid: false,
    };
  },
  methods: {
    YZInfo(fun) {
      var isquasition = false;
      //身份验证
      this.bindUserInfo(() => {
        if (this.userInfo.hasOwnProperty("SFZH")) {
          if (this.userInfo.SFZH != this.ruleForm2.IdCard) {
            this.$message({
              message:
                "您输入的身份证号码与his或体检对应的身份证号码不一致，否则请前往医院相关部门进行修改！",
              type: "error",
              duration: 1000,
            });
            isquasition = true;
          }
          // if (this.userInfo.PHONE != this.ruleForm2.Phone) {
          //   this.$message({
          //     message:
          //       "您输入的手机号码与his或体检对应的手机号码不一致，请尝试输入身份证号后按回车自动绑定正确号码，请前往医院相关部门进行修改！",
          //     type: "error",
          //     duration: 1000,
          //   });
          // }
           if (JSON.stringify(this.userInfos).indexOf(this.ruleForm2.Phone)==-1) {
            this.$message({
              message:
                "您输入的手机号码与his或体检对应的手机号码不一致，请尝试输入身份证号后按回车自动绑定正确号码，请前往医院相关部门进行修改！",
              type: "error",
              duration: 1000,
            });
          }
        } else {
          if (this.userInfo.idCardNo != this.ruleForm2.IdCard) {
            this.$message({
              message:
                "您输入的身份证号码与his或体检对应的身份证号码不一致，请前往医院相关部门进行修改！",
              type: "error",
              duration: 1000,
            });
            isquasition = true;
          }
          // if (this.userInfo.phone != this.ruleForm2.Phone) {
          //   this.$message({
          //     message:
          //       "您输入的手机号码与his或体检对应的手机号码不一致，请尝试输入身份证号后按回车自动绑定正确号码，请前往医院相关部门进行修改！",
          //     type: "error",
          //     duration: 1000,
          //   });
          //   isquasition = true;
          // }
          // console.log(this.userInfos);
          // console.log(JSON.stringify(this.userInfos).indexOf(this.ruleForm2.Phone));
            if (JSON.stringify(this.userInfos).indexOf(this.ruleForm2.Phone)==-1) {
            this.$message({
              message:
                "您输入的手机号码与his或体检对应的手机号码不一致，请尝试输入身份证号后按回车自动绑定正确号码，请前往医院相关部门进行修改！",
              type: "error",
              duration: 1000,
            });
            isquasition=true;
          }
        }
        if (isquasition == false) {
          fun();
        }
      });
    },
    getAuthCode: function () {
      var that=this;
      var FUN=function () {
        if (that.sendAuthCode == false) {
          return false;
        }
        if (that.IsValid) {
          return false;
        }
        // 验证非空
        if (
          that.ruleForm2.IdCard == "" ||
          that.ruleForm2.IdCard == null ||
          that.ruleForm2.IdCard == undefined
        ) {
          that.$message({
            message: "请输入身份证号",
            type: "error",
            duration: 1000,
          });
          return false;
        }
        if (
          that.ruleForm2.Phone == "" ||
          that.ruleForm2.Phone == null ||
          that.ruleForm2.Phone == undefined
        ) {
          that.$message({
            message: "请输入手机号",
            type: "error",
            duration: 1000,
          });
          return false;
        }
        var phonedata = {
          phone: that.ruleForm2.Phone,
        };
        that.$http.post(baseUrl + "/GetSmsInfo", phonedata).then((res) => {
          if (res.data.success == false) {
            that.message({
              message:
                "您输入的身份证对应的电话有误！请前往医院收费处进行信息修改",
              type: "error",
            });
            return false;
          }
          that.key = res.data.key;
        });

        that.sendAuthCode = false;
        that.auth_time = 60;
        var auth_timetimer = setInterval(() => {
          that.auth_time--;
          if (that.auth_time <= 0) {
            that.sendAuthCode = true;
            clearInterval(auth_timetimer);
          }
        }, 1000);
      };
      this.YZInfo(FUN);
    },
    toGoQuery: function () {
      this.bindUserInfo(() => {
        console.log(this.key);
        //验证码的验证
        this.$http
          .get(baseUrl + "/GetsmsResult?key=" + this.key)
          .then((res) => {
            if (res.data.code == 200) {
              if (res.data.msg.search(this.ruleForm2.validCode) != -1) {
                if (this.userInfo.hasOwnProperty("SFZH")) {
                  this.$router.push({
                    path: "/about", //路径携带参数
                    query: {
                      cardNo: this.userInfo.DJLSH,
                      Name: this.userInfo.XM,
                      idcard: this.userInfo.SFZH,
                      address: "",
                    },
                  });
                } else {
                  this.$router.push({
                    path: "/about", //路径携带参数
                    query: {
                      cardNo: this.userInfo.cardNo,
                      Name: this.userInfo.patientName,
                      idcard: this.userInfo.idCardNo,
                      address: this.userInfo.address,
                    },
                  });
                }
              } else {
                this.$message({
                  message: "验证码错误" + res.data.data,
                  type: "error",
                });
              }
            } else {
              this.$message({
                message: "验证码已过时" + res.data.data,
                type: "error",
              });
            }
          });
      });
      //暂时屏蔽便于测试
    },
    Onkeydown: function (e) {
      var evt = window.event || e;
      if (evt.keyCode == 13) {
        this.bindUserInfo(() => {
          this.ruleForm2.Phone = this.userInfo.phone;
          this.ruleForm2.IdCard = this.userInfo.idCardNo;
        });
      }
    },
    getUserInfo(func, obj) {
      this.$http.post(baseUrl + "/bindCard", obj).then((res) => {
        func(res);
      });
    },
    bindUserInfo(func) {
      var data = {
        idcard: this.ruleForm2.IdCard,
      };
      this.getUserInfo((res) => {
        if (res.data.code == 404 || res.data.code == 500) {
          alert(res.data.data);
          return;
        } else {
          this.userInfo = res.data.data[0];
          this.userInfos=res.data.data;
          console.log(res.data);
          func();
        }
      }, data);
    },
  },
  components: {},
  mounted: function () {
    // console.log(this.key);
    // this.$message({
    //   message:"成功",
    //   type:"success"
    // })
  },
};
</script>
<style lang="scss" scope>
// @media  screen and (min-width: 610px) ,screen and (min-device-width: 610px){
//     body{
//         background-color:yellow;
//     }
// }

// @media  screen and (max-width: 600px) ,screen and (max-device-width: 600px){
//     body{
//         background-color:red;
//     }
// }
@media screen and (max-width: 600px) {
  body {
    background-image: url("/imgs/5.png");
    background-repeat: no-repeat;
    background-size: cover;
    width: 100%;
    height: 40rem;
  }
  .login-page {
    -webkit-border-radius: 5px;
    border-radius: 5px;
    margin: 180px auto;
    width: 80%;
    height: 50%;
    padding: 35px 35px 15px;
    background: #fff;
    border: 1px solid #eaeaea;
    box-shadow: 0 0 25px #cac6c6;
  }
}
* {
  padding: 0;
  margin: 0;
  box-sizing: border-box;
}
@media screen and (min-width: 600px) {
  body {
    background-image: url("/imgs/4.jpg");
    // background-repeat: no-repeat;
    background-size: cover;
    width: 100%;
  }
  .login-page {
    -webkit-border-radius: 5px;
    border-radius: 5px;
    margin: 180px auto;
    width: 50%;
    height: 50%;
    padding: 35px 35px 15px;
    background: #fff;
    border: 1px solid #eaeaea;
    box-shadow: 0 0 25px #cac6c6;
  }
}
// body {
//   background-image: url("/imgs/4.jpg");
//   // background-repeat: no-repeat;
//   background-size: cover;
//   width: 100%;
// }

.login-container {
  width: 100%;
  height: 100%;
}

label.el-checkbox.rememberme {
  margin: 0px 0px 15px;
  text-align: left;
}
.showyzm {
  position: relative;
  #yzm {
    width: 60%;
  }
  #btnyzm {
    position: absolute;
    top: 0;
    left: 62%;
    .auth_text_blue {
      color: blue;
      width: 100%;
    }
    .send {
      color: #1111;
    }
  }
}
</style>